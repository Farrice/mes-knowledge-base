# Eightward Visual Brand Book Preview

Open `index.html` to review the visual package.

This is a private concept preview for Josh. It contains three original visual directions:

1. After Seven Social Club
2. Floorcraft Utility
3. Debug Club Afterimage

The package uses original illustrative SVG mockups and local CSS only. It does not use historic photos, event marks, songs, lyrics, famous dancer likenesses, or public launch assets.

Recommended decision: lead with After Seven, borrow product utility from Floorcraft, and keep Debug Club as the satellite joke line.
